# Node.js Shopping Cart Via Stripe API

Clone this repository to obtain the starter code for this project. It includes the html and css files as well as some starter Javascript code. Together we will be adding in the details to the store page, as well as setting up Stripe API to enable transactions.

Link to original YouTube tutorial: https://www.youtube.com/watch?v=mI_-1tbIXQI

Original creators GitHub: https://github.com/WebDevSimplified
